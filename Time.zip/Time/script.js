jblet interval;
let currentCycle = 0;
let isFocus = true;

function startTimer() {
    let focusTime = parseInt(document.getElementById("focusTime").value) * 60;
    let breakTime = parseInt(document.getElementById("breakTime").value) * 60;
    let cycles = parseInt(document.getElementById("cycles").value);

    currentCycle = 0;
    isFocus = true;

    function runCycle() {
        if (currentCycle >= cycles) {
            document.getElementById("status").innerText = "تم الانتهاء من جميع الدورات!";
            return;
        }

        let time = isFocus ? focusTime : breakTime;
        document.getElementById("status").innerText = isFocus ? "وقت التركيز!" : "وقت الراحة!";
        startCountdown(time, () => {
            isFocus = !isFocus;
            if (!isFocus) currentCycle++;
            runCycle();
        });
    }

    runCycle();
}

function startCountdown(duration, callback) {
    clearInterval(interval);
    let remainingTime = duration;

    interval = setInterval(() => {
        let minutes = Math.floor(remainingTime / 60);
        let seconds = remainingTime % 60;
        document.getElementById("countdown").innerText = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        if (remainingTime <= 0) {
            clearInterval(interval);
            callback();
        }
        remainingTime--;
    }, 1000);
}

function updateEgyptTime() {
    let options = { timeZone: "Africa/Cairo", hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
    let timeString = new Date().toLocaleTimeString("ar-EG", options);
    document.getElementById("egypt-time").innerText = `التوقيت في مصر: ${timeString}`;
}

setInterval(updateEgyptTime, 1000);
updateEgyptTime();